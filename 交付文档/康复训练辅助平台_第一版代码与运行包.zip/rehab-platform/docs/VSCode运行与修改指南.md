# VS Code 运行与修改指南

本指南对应当前 0.1 版。程序使用 Java 8、Spring Boot 2.7.18、MyBatis、Vue 3 和 Python 标准库，默认连接 H2 文件数据库；MySQL 配置与建表脚本已提供，但尚未进行真实 MySQL 联调。

## 一 打开正确的项目文件夹

在 VS Code 中选择“文件 → 打开文件夹”，打开：

```text
E:\2025work\6-project\project1_work\rehab-platform
```

这个文件夹内应直接看到 `web`、`server`、`algorithm`、`database` 和 `start.ps1`。本指南中的终端命令默认从这个项目根目录执行。

若已在系统中配置 `code` 命令，也可以从 PowerShell 打开：

```powershell
code 'E:\2025work\6-project\project1_work\rehab-platform'
```

通过“终端 → 新建终端”打开 PowerShell。检查环境：

```powershell
java -version
node --version
python --version
```

本机上次验证的版本为 Java 8.0.201、Node.js 24.12 和 Python 3.12.7。Maven 为工作区便携版，不需要系统全局安装。先用终端即可运行，不依赖 Java 调试插件；如安装 Java 扩展，需另行满足扩展本身的工具 JDK 要求，项目的 Java 目标版本仍由 `server/pom.xml` 决定。

## 二 直接运行已有版本

在项目根目录终端执行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\start.ps1 -SkipBuild -NoBrowser
```

出现 `READY` 或 `already running` 后，打开：

```text
http://127.0.0.1:8080
```

`-SkipBuild` 表示运行已有 jar 和前端构建，不会编译刚修改的 Java / Vue 源码。`-NoBrowser` 只是让脚本不自动打开浏览器。

脚本将 Java 和 Python 放到后台运行；关闭该终端不会自动停止平台。停止时执行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\stop.ps1
```

演示账号：`trainee`、`teacher`、`admin`，密码统一为 `Demo123!`。

## 三 修改前端时的运行方式

先按上一节启动后台服务，保持 Java 8080 和 Python 8001 运行。再新建一个 VS Code 终端：

```powershell
cd web
npm.cmd run dev
```

如果新解压的项目还没有 `node_modules`，先执行一次 `npm.cmd ci`，再运行开发服务器。

打开 `http://127.0.0.1:5173`。修改 `web/src` 内的 Vue、JS 和 CSS，保存后通常会自动更新页面。`web/vite.config.js` 将 `/api` 代理到 Java 的 8080，因此业务和数据库访问仍由 Java 负责。

两个地址的区别：

| 地址 | 用途 | 修改 Vue 源码后是否立即更新 |
| --- | --- | --- |
| `127.0.0.1:5173` | Vite 开发页面 | 支持热更新 |
| `127.0.0.1:8080` | Java 提供的已构建页面 | 需重新执行前端构建 |

按 `Ctrl+C` 关闭前端开发终端，只停止 Vite，不会停止后台 Java 和 Python。

## 四 修改 Java 后重新构建

最直接的方法是在项目根目录执行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\stop.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\start.ps1 -NoBrowser
```

第二条命令会编译 Java、构建前端并启动服务。Java 源码修改后必须重新编译；刷新浏览器不会让运行中的旧 jar 自动更新。

也可以双击 `构建并启动.cmd`。它会先停止本项目后台进程，再构建和启动。编译首次需要网络，后续会利用已下载的依赖缓存。

## 五 三个终端分别运行

当你需要直接观察 Java 和 Python 日志时，先运行停止脚本，避免与后台服务占用同一端口。确认项目已有构建，然后分别打开三个终端。

终端一，项目根目录：

```powershell
python -u algorithm/service.py
```

终端二，项目根目录：

```powershell
cd server
java -Dfile.encoding=UTF-8 -jar target/rehab-platform-0.1.0.jar
```

终端三，项目根目录：

```powershell
cd web
npm.cmd run dev
```

此时访问 5173。修改 Python 后，在终端一按 `Ctrl+C`，再重新执行 Python 启动命令；本版没有 Python 自动重载。修改 Java 后先停止终端二，再重新构建；修改前端无需停止其他服务。

Java 一定从 `server` 工作目录启动，因为 H2 的 `./data/rehab` 是相对于工作目录的。如果在不同目录启动，可能连接到另一个新建数据文件，表现为“原有数据不见了”。

前台运行的 Java / Python 应在对应终端按 `Ctrl+C` 停止；`stop.ps1` 主要管理它自己记录过 PID 的后台实例，不用于猜测和终止手动启动的进程。

## 六 使用已配置的 VS Code 任务

项目已增加 `.vscode/tasks.json`。按 `Ctrl+Shift+P`，输入 `Tasks: Run Task`，选择以下任务：

| 任务 | 用途 |
| --- | --- |
| 舒展：启动平台（已有构建） | 直接启动或复用后台平台 |
| 舒展：停止后台平台 | 停止启动脚本记录的本项目进程 |
| 舒展：重新构建并启动 | 先停止后台平台，再编译 Java / Vue 并启动 |
| 舒展：前端开发（热更新） | 在独立终端运行 Vite |
| 舒展：Python 分析服务（前台） | 手动分终端模式使用；不要与后台 Python 重复启动 |
| 舒展：Java 后端（已有构建，前台） | 手动分终端模式使用；不会自动编译 Java |
| 舒展：Python 规则测试 | 验证模拟特征与分项规则 |
| 舒展：数据库事务与版本测试 | 使用独立内存数据库验证回滚和并发版本 |

建议日常修改页面时使用“启动平台（已有构建）”与“前端开发（热更新）”；修改 Java 后使用“重新构建并启动”。

## 七 目录结构

```text
rehab-platform/
├─ .vscode/
│  └─ tasks.json                    VS Code 启动、开发和测试任务
├─ web/                            Vue 前端
│  ├─ src/
│  │  ├─ App.vue                   角色页面、表单和页面交互
│  │  ├─ api.js                    请求封装、token 与导出
│  │  ├─ style.css                 页面布局、配色和响应式样式
│  │  ├─ main.js                   Vue 与 Element Plus 入口
│  │  └─ components/
│  │     ├─ Pose.vue               模拟骨架 SVG
│  │     └─ Chart.vue              ECharts 图表封装
│  ├─ vite.config.js               开发端口与 API 代理
│  ├─ package.json                 依赖与 npm 命令
│  ├─ package-lock.json            锁定前端依赖版本
│  └─ dist/                       构建产物，不在这里修改页面
├─ server/                         Java 业务后端
│  ├─ pom.xml                     依赖、Java 目标版本和打包
│  ├─ src/main/java/edu/course/rehab/
│  │  ├─ Application.java         Spring Boot 启动入口
│  │  ├─ Api.java                 HTTP 接口
│  │  ├─ RehabService.java        业务规则、权限归属、事务与分析调用
│  │  ├─ Store.java               MyBatis SQL 与数据库映射
│  │  ├─ Auth.java                token 校验与接口拦截
│  │  ├─ DataInitializer.java     首次初始化演示账号、动作和计划
│  │  └─ Errors.java              统一异常响应
│  ├─ src/main/resources/
│  │  ├─ application.yml         默认端口、H2 与 Python 地址
│  │  ├─ application-mysql.yml   MySQL 连接配置
│  │  └─ schema.sql              默认 H2 建表脚本
│  ├─ data/                       本机持久化数据库，不是源码
│  └─ target/                     Java 构建产物
├─ algorithm/
│  ├─ service.py                  模拟特征生成与分项规则分析
│  └─ test_service.py             Python 规则测试
├─ database/
│  ├─ 01_schema_mysql.sql         MySQL 8 建表脚本
│  ├─ 02_queries.sql              联表、聚合、版本与索引查询示例
│  └─ README.md                   数据关系和约束说明
├─ tests/
│  ├─ smoke_test.py               运行中平台的业务联调
│  └─ transaction_check.py        隔离数据库事务与并发版本测试
├─ docs/
│  ├─ VSCode运行与修改指南.md     本指南
│  └─ preview.jpg                 第一版页面预览
├─ .runtime/                      启动日志和后台进程 PID
├─ README.md                      快速运行和版本范围
├─ TEST_REPORT.md                 已验证功能与验证边界
├─ start.ps1 / stop.ps1           启动与停止脚本
└─ 启动平台.cmd / 构建并启动.cmd / 停止平台.cmd
```

开发依赖缓存 `.tools` 当前位于项目的上一级工作区；脚本也支持在新位置的项目内部创建 `.tools`。它不是业务代码，也不应当作为课程核心成果提交。

## 八 重要文件怎么改

| 你要做的修改 | 主要入口 | 修改思路与关联工作 |
| --- | --- | --- |
| 页面文字、布局、按钮 | `web/src/App.vue`、`style.css` | 先用 5173 热更新；增加按钮时同时确认对应 API 已存在。 |
| 图表和骨架展示 | `components/Chart.vue`、`Pose.vue` | 图表展示逻辑与业务数据分开；Pose 当前只是示意图，不能直接改标签声称已经识别摄像头。 |
| 新增或修改接口 | `Api.java`、`RehabService.java`、`api.js` | 接口确定参数和返回值，业务层做归属校验及事务，前端对齐字段。 |
| SQL、统计和查询优化 | `Store.java`、`02_queries.sql` | 新增聚合 SQL 和索引后，使用真实记录验证统计口径，用 EXPLAIN 说明索引效果。 |
| 新增数据库字段 | `schema.sql`、`01_schema_mysql.sql` | 同步 Java 写入和查询、前端表单及数据说明；已有数据库要执行版本化 ALTER，不能只改 CREATE TABLE IF NOT EXISTS。 |
| 修改默认账号或动作 | `DataInitializer.java` | 只在用户表为空时运行；修改它不会更新已有数据。已运行数据库应使用明确的更新 SQL 或后续管理接口。 |
| 修改规则和模拟偏差 | `algorithm/service.py` | 改完先跑规则测试，保留分项判断与事件依据；旧训练不重新计算。 |
| 切换 MySQL 或服务端口 | `application*.yml`、`vite.config.js`、`start.ps1` | 端口和数据库变更要同步启动脚本、前端代理及文档，避免一个地方改完其他地方仍使用旧地址。 |

建议先阅读 `Api.java → RehabService.java → Store.java → schema.sql`，理解一条请求如何到达数据库，再阅读 `App.vue` 中调用这些接口的方法。

### 页面代码的后续拆分

`App.vue` 当前把页面放在一起，便于第一版快速跑通。扩展功能前可逐步拆为：

```text
web/src/views/
  LoginView.vue
  OverviewView.vue
  PlansView.vue
  TrainingView.vue
  ReportsView.vue
  ExerciseLibraryView.vue
  FlowerGameView.vue
  DatabaseView.vue
```

先拆计划和报告页面，把登录状态放到单独的 store / composable，把计划编辑和复核弹窗做成组件；每拆一页，验证它的请求和权限不变。不要把拆分、接口改名和数据库迁移混在一次修改中。

### Java 代码的后续拆分

随着业务增加，可以将 `Api.java` 拆为计划、会话、复核、统计几个 Controller；将 `Store.java` 拆为多个 Mapper，并把复杂联表 SQL 移入 XML。增加明确的请求和响应 DTO，逐步替换当前原型中的 Map 参数。保留服务层的数据归属检查、事务边界和并发防重。

## 九 数据库课程优先补什么

1. 配置 MySQL 8，执行建表脚本，跑同一套业务联调，记录 H2 与 MySQL 的差异。
2. 建立数据字典：字段含义、类型、主外键、非空、唯一、范围约束及索引。
3. 完善训练者档案和基线编辑，让已有表参与真实业务维护。
4. 把概览中的部分 Java 内存统计改为明确的 SQL 聚合查询；补充测试数据规模和 EXPLAIN 对比。
5. 完成 ER 图、关系模式及规范化说明，解释版本快照和汇总字段为何保留。
6. 为表结构变更添加迁移脚本；保留计划、规则和人工复核历史。

数据库流程稳定后，再接摄像头与质量模型。真实识别可以优先使用浏览器 MediaPipe 采集关键点，Python 分析动作片段，Java 校验并保存结果；这需要另加真实特征分析接口，不能直接把 `/simulate` 的标签改为实时识别。

## 十 重要文档如何维护

| 文档 | 什么时候修改 | 应写什么 |
| --- | --- | --- |
| `README.md` | 启动、环境或版本范围变化 | 当前真实可运行步骤、账号、端口、数据库及尚未完成的功能。 |
| `database/README.md` | 关系、字段、约束或统计口径变化 | ER 图、关系模式、字段含义、规范化、索引及必要冗余。后续可拆出数据字典。 |
| `TEST_REPORT.md` | 实际完成验证后 | 环境、用例、输入、结果与未覆盖项；未跑过的 MySQL / 模型测试保持待验证。 |
| 本指南 | VS Code 任务或文件结构变化 | 工作目录、命令、重启方式及修改入口。 |
| 后续 `docs/API.md` | 接口稳定后新增 | Java 与 Python、前端与 Java 的参数、返回示例、错误码和版本。 |
| 选题说明 Word | 范围或技术路线变化 | 区分“拟实现”和“已完成”；当前内置 H2、模拟动作与鼠标花朵应如实注明，MySQL、真实识别和模型训练按进度更新。 |

数据库文件不应为了更新种子数据而直接删除。先停止服务并备份 `server/data/rehab.mv.db`，再设计更新或迁移方式。

## 十一 验证修改

规则修改后：

```powershell
python -m unittest discover -s algorithm -p test_service.py -v
```

数据库或事务修改后：

```powershell
python tests/transaction_check.py
```

完整流程修改后，在平台运行时执行：

```powershell
python tests/smoke_test.py
```

联调脚本会在演示库增加测试计划、报告和反馈。事务测试使用独立内存数据库与 18082 / 18001 端口，结束后关闭测试进程，不修改演示库。
